package com.iiht.evaluation.coronokit.dao;

public @interface deleteProduct {

}
