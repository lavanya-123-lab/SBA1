import java.sql.DriverManager;

import com.mysql.jdbc.Connection;
import java.sql.*;

public class jdbc {

	
		
		static String driver="com.mysql.jdbc.Driver";
		static String url="jdbc:mysql://localhost:3306/coronakit";
		static String uname="root";
		static String pwd="";
		public static void main(String[] args) {
		try {
			Class.forName(driver);
			java.sql.Connection con=DriverManager.getConnection(url, uname, pwd);
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from productmaster");
			while(rs.next()) {
				System.out.println(rs.getString(1));
			}
			rs.close();
			con.close();
			
		

	} catch (ClassNotFoundException e) {e.printStackTrace();
	}catch(SQLException e) {
		e.printStackTrace();
	}

}
}
